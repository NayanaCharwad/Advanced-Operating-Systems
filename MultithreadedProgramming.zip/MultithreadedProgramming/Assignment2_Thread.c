//Include files
#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<curses.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>

//Shared variables between multiple threads
int z,q,s,S,t=0;
int i,j,k=0;


//declaring the Matrix function;
void *Matrix();
//declaration of accepting command input function
void *AcceptInput();
//declaration of function to read file
void *ReadFile();

int flag=0;

int main()
{

pthread_t   Matrix_multiplication,Accept_Input,Read_File;//the thread identifier
pthread_attr_t attr,attr1,attr2; //set of thread attributes

//get the default attributes
pthread_attr_init(&attr);
//creat the thread for matrix multiplication
pthread_create(&Matrix_multiplication,&attr,Matrix,NULL);

//Create thread to take input from user
pthread_attr_init(&attr1);
pthread_create(&Accept_Input,&attr1,AcceptInput,NULL);

//Create thread for reading input file
pthread_attr_init(&attr2);
pthread_create(&Read_File,&attr2,ReadFile,NULL);

    while(1)
    {

//check which operation to be performed
//save matrix multiplication result to output file and terminate
 	if (z==1)
	{	
            //wait for matrix multiplication thread to end and then exit 
            (void)pthread_join(Matrix_multiplication,NULL);
	    printw("Multiplication Result Written To Output File\n");  
	    wrefresh(stdscr);
	    endwin();
	    //terminate	
            exit(0);
	}

//terminate program
	else if (q==1)
	{
	     endwin();	
             exit(0);
	}

//display row,column and intermediate row column
        else if (s==1)
	{
	     printw("\nRow:%d, Column:%d, Intermediate Row/Column:%d\n",i,j,k);
             wrefresh(stdscr);	
	     s = 0;	
	}
//stop matric multiplication
	else if (S==1)
	{
	     printw("\nMatrix Multiplication Stopped !");
             printw("\nRow:%d, Column:%d, Intermediate Row/Column:%d\n",i,j,k);
	     wrefresh(stdscr);	
	}

//start matrix multiplication again
	else if (t==1)
	{
	     (void)pthread_join(Matrix_multiplication,NULL);
	      t=0;
	      printw("\nMatrix Multiplication Started Again!\n");	
	      wrefresh(stdscr);	
	      pthread_create(&Matrix_multiplication,&attr,Matrix,NULL);
	}
      }  

     return(0);
}

//Function for thread to accept input from user from command line
void *AcceptInput()
{
    int input;
    initscr();
    cbreak();
    keypad(stdscr,TRUE);
  
while(1)
  {			

    input = getch();

//set shared variables based on input
    switch(input)	
    {
    
	case 's':	  	 
            s = 1;
	  break;
               
   	 case 'S':
           S = 1;
	   break;    
    
   	 case 'z':
          z = 1;    
          pthread_exit(0);  
	  break;
   
   	 case 'q':
          q = 1;    
          pthread_exit(0);	
	  break;

         case 't':
   	  t = 1;    
	  break;                     
   }
}
}

//function for thread to check if something is entered in input file
void *ReadFile()
{
  char file[] = "sharedfile.txt";
  char time[ 100 ] = "";
  char time1[ 100 ] = "";
  struct stat b;
  FILE *file_in;
  char command;

//check current file modification date and time      
  if (!stat(file, &b)) 
  {
  strftime(time, 100, "%d/%m/%Y %H:%M:%S", localtime( &b.st_mtime));
  } 
  else 
  {
  printw("Cannot display the time.\n");
  }
  
  while(1)
  {
//chceck if file is modified or not
   if (!stat(file, &b)) 
   {
   strftime(time1, 100, "%d/%m/%Y %H:%M:%S", localtime( &b.st_mtime));
   if (strcmp(time,time1)!=0)
   {
      strcpy(time,time1);
//read file and update shared variables
      file_in = fopen("sharedfile.txt","r");

      if (file_in == NULL)
      {
         printw("\nError Opening Output File");          
      }
      
      else
      {
           fscanf(file_in,"%c",&command);
           if (command == 's')
           {
              s = 1;        
           }
           if(command == 'S')
           {
              S = 1;                         
           }
           if (command == 'z')
           {
              z = 1;                         
	      pthread_exit(0);
           }
           if (command == 'q')
           {
              q = 1;          
	      pthread_exit(0);	               
           }
           if (command == 't')
           {
              t = 1;                         
           }
           fclose(file_in);
       }     
   }           
  }
}
}


void *Matrix()
{
 //define matrices
    int matrix1[10][10], matrix2[10][10], result[10][10];
    int res,i1,j1;
        
    //initialize matrices to random numbers from 1 to 11
    for (i1=0;i1<10;i1++)
    {
        for (j1=0;j1<10;j1++)
        {
            matrix1[i1][j1] = j1+1;
            matrix2[i1][j1] = j1+1;
	    result[i1][j1]=0;
        }
     }

     
//repeatedly Multiply both matrices
   while(1)
   {
//check if z changed
   if(z==1)
   {    
      FILE *file_out;
      file_out = fopen("output.txt","w+");

//write output to output file
      if (file_out == NULL)
      {
         printw("\nError Opening Output File");          
      }
      
      else
      {
       fprintf(file_out,"\n------------------------------------------------------------------------------");
       fprintf(file_out,"\n   Output Of Matrix Multiplication         ");                          
       fprintf(file_out,"\n------------------------------------------------------------------------------");             
       fprintf(file_out,"\n\nResultant Matrix \n");             
       for(i1=0;i1<10;i1++)
       {
         fprintf(file_out,"\n");             
         for(j1=0;j1<10;j1++)
         {
            fprintf(file_out,"\t%d",result[i1][j1]);
         }
        } 
        fprintf(file_out,"\n-----------------------------------------------------------------------------");             
      }
      
      fclose(file_out);	
//exit thread
     pthread_exit(0);
}

//exit thread
else if(q==1)
{
    pthread_exit(0);
}
else if(t==1)
{
    pthread_exit(0);
}
else
{
//multiply matrices
for(i=0;i<10;i++)
     {
       for(j=0;j<10;j++)
       {
          res = 0;
          for(k=0;k<10;k++)
          {
	     if(S==1)
		break;
             res = res + matrix1[i][k]*matrix2[k][j];
          }
	    if(S==1)
		break;
          result[i][j] = res;	   
       }
	    if(S==1)
		break;
      }
//exit thread
if(S==1)
{
  S=0;
  pthread_exit(0);}
}
}
}    

//end of program
  
