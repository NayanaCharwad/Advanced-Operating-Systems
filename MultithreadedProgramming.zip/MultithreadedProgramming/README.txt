Multithread Programming in Linux
Nayana Charwad 

Description:

All keys are mentioned as suggested only 's' key is replaced with S key to use single key enterning functionality of program.

The prgroam is designed to have 4 threads : 

Shared variables used : s,S,t,q,t (flags used for user command)
		       i,j,k (variables for row/column/intermediate row/column)

1. Main thread/Controller Thread : Which controls overall operation of all 3 running threads. 

2. AcceptInput thread : This thread is designed to accept inputs from user and set the values of shared variables/ shared flags based on user commands.

3. ReadFile thread : This thread is designed to check if sharedfile.txt is changed or modified with command. If sharedfile.txt is modified then the thread checks input command and set the values of shared variables/ shared flags based on user commands.

4. MatrixMultiplication thread : This thread performs matrix multiplication and updates row/column/intermediate row column variables which are then used by main thread to display those values. This thread also writes result to output file output.txt if user command is 'z'.

Answers to Questions:
1.Think about how you might do this without threads and about how responsive such a program would be.
Answer: The exact functionality of multithread program can't be acheived with single thread program. Some part of functionality can be achieved with single thread program such as command z : saving matrix result to output file, q:terminate program, t: Restart matrix multiplcation but this can be done only one command at a time either from file/console. For example if user types z in console, program will perform functionality of z and then check if there is any other command to process or there is any command written in file. Concurrent execution of accepting inputs from user, multiplying matrices and accepting input from file won't be possible through single thread program.

2.Whats the different behavior you might see for user versus kernel threads? Is there a qualitative or quantitative experiment you can do that will clearly show the difference?
Answer: We know that kernel threads are entirely managed at kernel level by operating system whereas user thread are supported above kernel and managed without kernel support. Since kernel does not know anything about user threads, there would be poor communiction between user threads and operating system and kernel may stop the process/thread anywhere in between based on result of scheduling algorithm. On the other hand, for kernel threads kernel knows everything about them and can switch from one process to another at logical endpoint, when perticular thread finshes its operation. When we consider execution time, user thread are much faster than kernel threads since they get executed at user level above operating system. But user threads will work good for one to one or many to many multithread model otherwise single thread making an I/O call can block entire kernel. The experiment which we can do to see the difference is writing simple program with user threads as well as kernel threads which only implements basic functionality without having lot of system calls to I/O. Here user threads will work better than kernel threads as they would be faster and will not need much of system calls. Now, if we write another program having multiple I/O operations, kernel threads will work well as they can communicate well with operating system than user threads.
