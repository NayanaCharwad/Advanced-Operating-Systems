#include<stdio.h>
#include<stddef.h>
#include<semaphore.h>

//Global variable for producer and consumer
extern int n;

//extern semaphore  s_producer;
//extern semaphore  s_consumer;

//Function prototype for producer and consumer
//Consumer Function
void consumer(int count);

//Producer Function
void producer(int count); 
