/**
 * @file null.h
 *
 */
/* Embedded Xinu, Copyright (C) 2009.  All rights reserved. */


/* File automatically included by xinu.conf system for null device */
