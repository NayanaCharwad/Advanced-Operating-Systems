#define VERSION "(Embedded Xinu) (arm-rpi) #136 (tiwanyan@silo.soic.indiana.edu) Sat Nov 8 12:10:30 EST 2014"
