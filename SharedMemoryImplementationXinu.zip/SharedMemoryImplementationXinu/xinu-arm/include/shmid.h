#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define IPC_CREAT  1
#define IPC_ACCES  2
struct shmid_ds
{
   int			key;/*key of stuct*/
   char *		shm_seg;  /*pointer to shared segment*/
   int			shm_segsz; /*size of segment (bytes) */
   unsigned short  	shm_cpid;  /*pid of creator */
   unsigned short	shm_lpid;  /*pid of last operator */
   short		shm_nattch; /*no. of current attaches */
};

extern struct shmid_ds shmidtab[];

int shmget( int, int, int);
char* shmat( int);
int shmdt(int); 
