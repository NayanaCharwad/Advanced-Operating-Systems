#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<curses.h>

int z,q,s,S,t=0;
int i,j,k=0;
//declaring the Matrix function;
void *Matrix();
int flag=0;
int main()
{

pthread_t   Matrix_multiplication;//the thread identifier
pthread_attr_t attr; //set of thread attributes

//get the default attributes
pthread_attr_init(&attr);
//creat the thread
pthread_create(&Matrix_multiplication,&attr,Matrix,NULL);


//pthread_attr_init(&attr1);
//pthread_create(&Read_File,&attr1,ReadFile,NULL);

while(1)
{
//read input string
int input;
input=getchar();

switch(input){

//check if the inout letter is z,q,s,t
		case 'z':
			z=1;
                        (void)pthread_join(Matrix_multiplication,NULL);
                        exit(0);
                        break;
		case 'q':
                        q=1;
			exit(0);
			break;
		case 's':
			printf("i=%d,j=%d,k=%d\n",i,j,k);
			break;
		case 'S':
			S=1;
			break;
		case 't':
			t=1;
			(void)pthread_join(Matrix_multiplication,NULL);
			t=0;
			pthread_create(&Matrix_multiplication,&attr,Matrix,NULL);
		  	break;
		default:
			printf("\nIncorrect input");
}
}
return(0);
}

void *Matrix()
{
 //define matrices
    int matrix1[10][10], matrix2[10][10], result[10][10];
    int res,i1,j1;
        
    //initialize matrices to 1
    for (i1=0;i1<10;i1++)
    {
        for (j1=0;j1<10;j1++)
        {
            matrix1[i1][j1] = 1;
            matrix2[i1][j1] = 1;
	    result[i1][j1]=0;
        }
     }

     
     //repeatedly Multiply both matrices
   while(1)
{
//check if z changed
   if(z==1)
{     printf("write file is running\n");
      FILE *file_out;
      file_out = fopen("/Users/tiwanyan/Desktop/Output.txt","w+");

      if (file_out == NULL)
      {
         printf("\nError Opening Output File");          
      }
      
      else
      {
       fprintf(file_out,"\n------------------------------------------------------------------------------");
       fprintf(file_out,"\n   Output Of Matrix Multiplication         ");                          
       fprintf(file_out,"\n------------------------------------------------------------------------------");             
       fprintf(file_out,"\n\nResultant Matrix \n");             
       for(i1=0;i1<10;i1++)
       {
         fprintf(file_out,"\n");             
         for(j1=0;j1<10;j1++)
         {
            fprintf(file_out,"\t%d",result[i1][j1]);
         }
        } 
        fprintf(file_out,"\n-----------------------------------------------------------------------------");             
      }
      
      fclose(file_out);
     pthread_exit(0);
}
else if(q==1)
{
pthread_exit(0);
}
else if(t==1)
{
pthread_exit(0);
}
else
{
for(i=0;i<10;i++)
     {
       for(j=0;j<10;j++)
       {
          res = 0;
          for(k=0;k<10;k++)
          {
	     if(S==1)
		break;
             res = res + matrix1[i][k]*matrix2[k][j];
          }
	    if(S==1)
		break;
          result[i][j] = res;	   
       }
	    if(S==1)
		break;
      }

if(S==1)
{S=0;
pthread_exit(0);}
}
}
}    
  
