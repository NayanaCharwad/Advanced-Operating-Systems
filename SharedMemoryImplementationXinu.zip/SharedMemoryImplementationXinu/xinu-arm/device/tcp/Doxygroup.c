/**
 * @defgroup tcp TCP
 * @ingroup devices
 * @brief Transmission Control Protocol driver
 *
 * This module provides an interface to the Transmission Control Protocol (TCP).
 */
