/**
 * @defgroup raw Raw Packets
 * @ingroup devices
 * @brief Send and receive raw packets.
 */
