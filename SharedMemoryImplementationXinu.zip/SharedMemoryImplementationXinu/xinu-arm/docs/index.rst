.. _contents:

Embedded Xinu documentation contents
====================================

.. toctree::
   :maxdepth: 2
   :glob:

   Introduction
   Getting-Started
   features/index
   mips/index
   arm/index
   teaching/index
   projects/index
   development/index
