Assignment: Scanner
===================

Overview
--------

In this project students build the first step of a full compiler by
implementing a Scanner for our `Concurrent
MiniJava <http://www.mscs.mu.edu/~brylow/cosc4400/Spring2011/ConcurrentMiniJava.html>`__
language.

Notes
-----

Our `modifications to
MiniJava <http://www.mscs.mu.edu/~brylow/cosc4400/Spring2011/ConcurrentMiniJava.html>`__
require the addition of the *Xinu*, *Thread*, and *run* reserved words.
