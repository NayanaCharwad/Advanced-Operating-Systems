WRT54GL
=======

This page lists details about the `Linksys <http://www.linksys.com>`__
WRT54GL device.

Hardware Info
-------------

As reported by OpenWRT
~~~~~~~~~~~~~~~~~~~~~~

-  **eth0**: Broadcom 47xx 10/100BaseT Ethernet
-  **eth1**: Broadcom BCM4320 802.11 Wireless Controller 3.90.37.0

See also
--------

-  WRT54G

