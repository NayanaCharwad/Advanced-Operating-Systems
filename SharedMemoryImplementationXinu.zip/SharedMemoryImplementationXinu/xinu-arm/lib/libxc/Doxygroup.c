/**
 * @defgroup libxc C library
 * @brief A simple C library supporting a number of standard functions
 */
