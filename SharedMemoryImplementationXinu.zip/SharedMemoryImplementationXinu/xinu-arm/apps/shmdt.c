#include<shmid.h>
//struct shmid_ds shmidtab;
int shmdt (int shmid)
{
	int KEY;
        struct shmid_ds * shm;
	shm=&shmidtab;
	KEY=shm[shmid].key;
      	int  size=shm[shmid].shm_segsz;
	char* segptr=shm[shmid].shm_seg;
	memfree(segptr,size);
	shm[shmid].key=0;
	shm[shmid].shm_seg=NULL;
	shm[shmid].shm_segsz=0;
	shm[shmid].shm_cpid=0;
	shm[shmid].shm_lpid=0;
	shm[shmid].shm_nattch=0;
	return KEY;
//	shmidtab[shmid].shm_nattch--;
}
