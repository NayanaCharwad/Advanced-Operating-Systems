#include<stdio.h>
#include<prodcons.h>
#include<semaphore.h>
#include<stdlib.h>

int n;
//semaphore s_producer;

//Producer function to produce values of n
void producer(int count)
{
	n = 0;
//initialize semaphore
//        s_producer = semcreate(0);

	while ( n <= count)
	{
//wait for consumer to be ready
//		wait(s_consumer);
//produce data
		n++;
		if (n<= count)
		{
			printf("\nProduced : %d\n",n);
		}
//signal consumer
//		signal(s_producer);
	}
}
