#include<stdio.h>
#include<prodcons.h>
#include<semaphore.h>
#include<stdlib.h>

//semaphore s_consumer;

//Consumer function to consume values of n
void consumer(int count)
{
//initialize semaphore
//	s_consumer = semcreate(1);

	while (n <= count)
	{
//wait for producer to produce data
//		wait(s_producer);
//consume data
		printf("\n Consumed : %d\n",n);
//signal producer
//		signal(s_consumer);				
	}
}
