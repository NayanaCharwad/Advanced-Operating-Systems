#include<shmid.h>
//extern struct shmid_ds shmidtab;
int shmget(int key, int size, int shmflg)
{
		 struct shmid_ds* shm;
		shm=&shmidtab;
		int flag=0;
		int i;
		irqmask im;
		for(i=0;i<10;i++)
                {
                if(shm[i].key==key)
                {
                        flag=1;
                        break;
                }
                }
		im=disable();

	if(shmflg==IPC_CREAT)
	{
		if(flag==1)
		{
		restore(im);
		printf("Memory segement already exist");
		return -1;
		}
		else
		{
		shm[key].key=key;
		shm[key].shm_seg=memget(size);
		shm[key].shm_segsz=size;
		shm[key].shm_nattch++;
		restore(im);
		return key;
		}
	}
	if(shmflg==IPC_ACCES)
	{
		if(flag==1)
		{
		restore(im);
		return key;
		}
		else
		{
		restore(im);
		return -1;
		}
	}
}
