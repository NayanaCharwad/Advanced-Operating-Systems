#include<shmid.h>

//extern struct shmid_ds shmidtab;
char* shmat( int shmid)
{
	struct shmid_ds *shm;
	shm=&shmidtab;
	char * segptr = shm[shmid].shm_seg;
	return segptr;
}
