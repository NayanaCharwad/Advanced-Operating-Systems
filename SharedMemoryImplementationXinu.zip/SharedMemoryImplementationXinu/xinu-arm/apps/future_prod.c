#include<future.h>
#include<stdio.h>
#include<stdlib.h>

int future_prod(future *fut)
{
	int i,j;
	j=(int)fut;
	for(i=0;i<1000; i++)
	{
	j +=i;
	}
	printf("\n%d",j);
	future_set(fut,&j);
	return OK;
}
