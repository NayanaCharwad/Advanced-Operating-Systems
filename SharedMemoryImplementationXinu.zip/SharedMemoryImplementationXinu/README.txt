Implement Shared Memory
Nayana Charwad		

Description :

Initialize structure Shmidtab[10] in initialization file in system directory

program shimget function to create or access the memory


shmat to get the pointer to the memory


shmdt to free the memory 