Assignment to understand and implement futures 
Nayana Charwad 

Design Consideration:

State of FUTURE:

FUTURE_EMPTY � a future allocated for an operation by a call to future_alloc()
FUTURE_WAITING � a future on which a process is waiting, by a call tofuture_get(),
for a value to be assigned
FUTURE_VALID � a future that holds a value assigned by a call to future_set()

1. Producer will produce value and call system call future_set which will set value of future and set the future state to FUTURE_VALID.
2. Future_set will also see if there is any other process already waiting on same future or not (future state to FUTURE_WAITING). 
If a process is already waiting on that future then future_set will resume the process and set it in ready queue.
3. Consumer will call system call future_get to consume value of future. 
4. If value of future is not already set by producer then consumer process will be suspended and put in waiting queue (future state to FUTURE_WAITING).
5. If value is already produced then consumer will consume value in future_get and set future state to FUTURE_EMPTY
  
