Implementation of Standard File System Functions 
Nayana Charwad


Design Consideration:

Functions Written:

1. File Create : 
	-Create Root Directory Entry
	-Create Inode for file 

2. File Open :
	- Access directory entry details and Inode details and save it in Open File Table

3. File Close :
	- Remove the file from open file table

4. File Write :
	- Allocate next free block to file data
	- Write data to mentioned file block
	- Save block number to Inode details
	- Adjust file pointer
	- Repeat same process untill all data is consumed

5. File Read :
	- Get details of file from open file table
	- Read file blocks one by one as mentioned in Inode block details
	- Adjust file pointer accordingly
	
6. File seek
	- Adjust file pointer as per offset given