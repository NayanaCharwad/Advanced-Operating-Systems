Program hello command on xinu shell

Nayana Charwad 

Steps followed:

1. Created xsh_hello.c in xinu-arm/shell folder as the main function to determine if the input command is in correct format.
2. Created hello.h file in xinu-arm/include folder as the header file and defined the function printhello
3. Created hello.c in xinu-arm/apps folder so as to write function printhello 
4. Added hello.c to xinu-arm/Makerules 
5. Modifed the commandtab array to support the newly added hello command. 
8. Added function prototype in  xinu-arm/include/shell.h 