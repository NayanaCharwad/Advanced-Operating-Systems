// Header file for hello command
#include<stddef.h>
#include<stdio.h>

//Define print function
void printhello(char *);
