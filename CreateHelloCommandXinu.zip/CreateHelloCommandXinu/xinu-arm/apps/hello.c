//Print function for hello command
#include<hello.h>

//print function
void printhello(char * args)
{
	printf(" Hello %s, Welcome to the world of Xinu!\n",args);
}
