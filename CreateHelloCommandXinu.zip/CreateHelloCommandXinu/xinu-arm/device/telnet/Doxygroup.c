/**
 * @defgroup telnet Telnet
 * @ingroup devices
 * @brief Telnet client and server.
 */
